package com.LinhMods;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    
    private Button btnVpn, btnBlock;
    private TextView tvStatus;
    private boolean isVpnOn = false;
    private boolean isBlocking = false;
    private static final int VPN_REQUEST_CODE = 100;
    private static final int OVERLAY_PERMISSION_CODE = 101;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Khởi tạo views
        btnVpn = findViewById(R.id.btnVpn);
        btnBlock = findViewById(R.id.btnBlock);
        tvStatus = findViewById(R.id.tvStatus);
        
        // Kiểm tra quyền
        checkPermissions();
        
        // Set listeners
        btnVpn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleVpn();
            }
        });
        
        btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleBlock();
            }
        });
        
        updateUI();
    }
    
    private void checkPermissions() {
        // Kiểm tra quyền hiển thị overlay
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_PERMISSION_CODE);
            }
        }
    }
    
    private void toggleVpn() {
        if (!isVpnOn) {
            // Chuẩn bị VPN
            Intent intent = VpnService.prepare(this);
            if (intent != null) {
                startActivityForResult(intent, VPN_REQUEST_CODE);
            } else {
                startVpnService();
            }
        } else {
            stopVpnService();
        }
    }
    
    private void startVpnService() {
        Intent intent = new Intent(this, VpnService.class);
        intent.setAction("start");
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        
        isVpnOn = true;
        isBlocking = false;
        updateUI();
        
        Toast.makeText(this, "VPN đã bật", Toast.LENGTH_SHORT).show();
    }
    
    private void stopVpnService() {
        Intent intent = new Intent(this, VpnService.class);
        intent.setAction("stop");
        startService(intent);
        
        isVpnOn = false;
        isBlocking = false;
        updateUI();
        
        Toast.makeText(this, "VPN đã tắt", Toast.LENGTH_SHORT).show();
    }
    
    private void toggleBlock() {
        if (!isVpnOn) {
            Toast.makeText(this, "Bật VPN trước!", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Intent intent = new Intent(this, VpnService.class);
        
        if (!isBlocking) {
            intent.setAction("block");
            isBlocking = true;
            Toast.makeText(this, "Đã bật chặn download", Toast.LENGTH_SHORT).show();
        } else {
            intent.setAction("unblock");
            isBlocking = false;
            Toast.makeText(this, "Đã tắt chặn download", Toast.LENGTH_SHORT).show();
        }
        
        startService(intent);
        updateUI();
    }
    
    private void updateUI() {
        if (isVpnOn) {
            btnVpn.setText(R.string.vpn_off);
            btnBlock.setEnabled(true);
            
            if (isBlocking) {
                btnBlock.setText(R.string.block_off);
                btnBlock.setBackgroundColor(ContextCompat.getColor(this, R.color.red));
                tvStatus.setText("ĐANG CHẶN DOWNLOAD");
            } else {
                btnBlock.setText(R.string.block_on);
                btnBlock.setBackgroundColor(ContextCompat.getColor(this, R.color.green));
                tvStatus.setText("ĐANG CHO PHÉP DOWNLOAD");
            }
        } else {
            btnVpn.setText(R.string.vpn_on);
            btnBlock.setEnabled(false);
            btnBlock.setText("⚫ VPN ĐANG TẮT");
            btnBlock.setBackgroundColor(ContextCompat.getColor(this, R.color.gray));
            tvStatus.setText("VPN ĐANG TẮT");
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                startVpnService();
            } else {
                Toast.makeText(this, "Cần cấp quyền VPN", Toast.LENGTH_SHORT).show();
            }
        }
    }
}