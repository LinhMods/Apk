package com.LinhMods;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

public class VpnConnection {
    
    // Kiểm tra gói tin có phải download không
    public boolean isDownloadPacket(byte[] packet, int length) {
        if (length < 20) return false;
        
        try {
            ByteBuffer buffer = ByteBuffer.wrap(packet, 0, length);
            
            // Lấy IP header
            int version = (buffer.get(0) >> 4) & 0x0F;
            if (version != 4) return false; // Chỉ xử lý IPv4
            
            int headerLength = (buffer.get(0) & 0x0F) * 4;
            
            // Lấy địa chỉ IP nguồn và đích
            byte[] srcIp = new byte[4];
            byte[] dstIp = new byte[4];
            
            buffer.position(12);
            buffer.get(srcIp);
            buffer.get(dstIp);
            
            // Kiểm tra nếu là gói tin từ internet về
            return isPublicIp(srcIp) && isLocalIp(dstIp);
            
        } catch (Exception e) {
            return false;
        }
    }
    
    private boolean isLocalIp(byte[] ip) {
        // 10.0.0.0/8
        if ((ip[0] & 0xFF) == 10) return true;
        
        // 172.16.0.0/12
        if ((ip[0] & 0xFF) == 172 && (ip[1] & 0xF0) == 16) return true;
        
        // 192.168.0.0/16
        if ((ip[0] & 0xFF) == 192 && (ip[1] & 0xFF) == 168) return true;
        
        return false;
    }
    
    private boolean isPublicIp(byte[] ip) {
        return !isLocalIp(ip) && (ip[0] & 0xFF) != 127 && (ip[0] & 0xFF) != 0;
    }
}