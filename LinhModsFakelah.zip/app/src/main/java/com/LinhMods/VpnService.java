package com.LinhMods;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class VpnService extends android.net.VpnService {
    
    private static final String TAG = "LinhModsVPN";
    private static final String CHANNEL_ID = "LinhModsVPNChannel";
    private static final int NOTIFICATION_ID = 1;
    
    private ParcelFileDescriptor vpnInterface;
    private ExecutorService executorService;
    private AtomicBoolean isRunning = new AtomicBoolean(false);
    private AtomicBoolean blockDownload = new AtomicBoolean(false);
    private VpnConnection vpnConnection;
    
    @Override
    public void onCreate() {
        super.onCreate();
        executorService = Executors.newSingleThreadExecutor();
        vpnConnection = new VpnConnection();
        createNotificationChannel();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            
            if ("start".equals(action)) {
                startVPN();
            } else if ("stop".equals(action)) {
                stopVPN();
            } else if ("block".equals(action)) {
                blockDownload.set(true);
            } else if ("unblock".equals(action)) {
                blockDownload.set(false);
            }
        }
        
        return START_STICKY;
    }
    
    private void startVPN() {
        if (isRunning.get()) return;
        
        // Chuẩn bị VPN
        Builder builder = new Builder();
        builder.setSession("LinhMods VPN");
        builder.setMtu(1500);
        
        // Thêm địa chỉ
        builder.addAddress("10.0.0.2", 32);
        builder.addRoute("0.0.0.0", 0);
        builder.addDnsServer("8.8.8.8");
        
        try {
            vpnInterface = builder.establish();
            
            if (vpnInterface != null) {
                isRunning.set(true);
                startForeground(NOTIFICATION_ID, createNotification());
                
                // Bắt đầu xử lý gói tin
                executorService.execute(new VpnRunnable());
            }
        } catch (Exception e) {
            Log.e(TAG, "Lỗi khởi tạo VPN: " + e.getMessage());
        }
    }
    
    private void stopVPN() {
        isRunning.set(false);
        blockDownload.set(false);
        
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (Exception e) {
                Log.e(TAG, "Lỗi đóng VPN: " + e.getMessage());
            }
            vpnInterface = null;
        }
        
        stopForeground(true);
        stopSelf();
    }
    
    private class VpnRunnable implements Runnable {
        @Override
        public void run() {
            try {
                FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
                FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
                
                byte[] packet = new byte[32767];
                
                while (isRunning.get()) {
                    try {
                        int length = in.read(packet);
                        if (length <= 0) continue;
                        
                        // Kiểm tra nếu là gói download và đang chặn
                        if (blockDownload.get() && vpnConnection.isDownloadPacket(packet, length)) {
                            continue; // Chặn gói tin
                        }
                        
                        // Gửi gói tin đi
                        out.write(packet, 0, length);
                        
                    } catch (Exception e) {
                        Log.e(TAG, "Lỗi xử lý gói tin: " + e.getMessage());
                        break;
                    }
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Lỗi VPN thread: " + e.getMessage());
            }
        }
    }
    
    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
        );
        
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LinhMods VPN")
            .setContentText("VPN đang chạy...")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        
        if (blockDownload.get()) {
            builder.setContentText("Đang chặn download");
        }
        
        return builder.build();
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "LinhMods VPN Channel",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Kênh thông báo VPN");
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        stopVPN();
        if (executorService != null) {
            executorService.shutdown();
        }
        super.onDestroy();
    }
}